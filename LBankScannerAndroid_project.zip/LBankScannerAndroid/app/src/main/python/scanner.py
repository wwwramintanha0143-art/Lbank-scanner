# -*- coding: utf-8 -*-
# LBank USDT Futures - Descending Trendline Scanner
# Android APK | Python engine
# 120 کندل 4 ساعته | حداقل 3 برخورد | عدم تکرار 10 روزه

import os
import json
import time
import random
import threading
import requests
import websocket

from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

# ==================== تنظیمات ====================

CANDLES = 120
INTERVAL = "240"
MAX_WORKERS = 4
MAX_RESULTS = 20

MAX_DISTANCE = 1.0
TOUCH_TOLERANCE = 0.75
MAX_BREAK = 1.0
MIN_TOUCHES = 3
MIN_SPAN = 20
MIN_TOUCH_GAP = 4
MAX_LAST_TOUCH_AGE = 30

COOLDOWN_DAYS = 10
RETRIES = 3
DATA_WAIT_SECONDS = 18
MAX_CACHE_AGE_HOURS = 12

DOWNLOAD_DIR = os.environ.get("SCANNER_DATA_DIR", "/storage/emulated/0/Download")
CACHE_FILE = os.path.join(DOWNLOAD_DIR, "trendline_candles_cache.json")
SEEN_FILE = os.path.join(DOWNLOAD_DIR, "trendline_seen_10days.json")
OUTPUT_FILE = os.path.join(DOWNLOAD_DIR, "trendline_futures_top20.json")

INSTRUMENT_URL = "https://lbkperp.lbank.com/cfd/openApi/v1/pub/instrument"
TV_URL = "wss://data.tradingview.com/socket.io/websocket"

EXCLUDED_BASES = {
    "USDT", "USDC", "BUSD", "TUSD", "FDUSD", "USDE", "DAI",
    "USDP", "USDD", "PYUSD", "EURC", "USD1", "UST", "USTC",
    "FRAX", "LUSD", "GUSD", "USDS", "PAXG", "XAUT"
}
EXCLUDED_NONCRYPTO = {
    "EUR", "BRL", "TRY", "JPY", "GBP", "AUD", "CAD", "CHF",
    "CNY", "HKD", "SGD", "INR", "KRW", "MXN", "ZAR", "RUB",
    "GOLD", "SILVER", "TSLA", "NVDA", "AAPL", "AMZN", "MSFT",
    "META", "SPY", "QQQ", "SPX500", "USO", "UNG", "GLD", "EWJ"
}


# Android app setup: use the app's private files directory and stream logs to the UI.
def configure(data_dir):
    global DOWNLOAD_DIR, CACHE_FILE, SEEN_FILE, OUTPUT_FILE
    import sys
    DOWNLOAD_DIR = data_dir
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    CACHE_FILE = os.path.join(DOWNLOAD_DIR, "trendline_candles_cache.json")
    SEEN_FILE = os.path.join(DOWNLOAD_DIR, "trendline_seen_10days.json")
    OUTPUT_FILE = os.path.join(DOWNLOAD_DIR, "trendline_futures_top20.json")
    log_path = os.path.join(DOWNLOAD_DIR, "scanner.log")
    sys.stdout = open(log_path, "a", encoding="utf-8", buffering=1)
    sys.stderr = sys.stdout

cache_lock = threading.Lock()
file_lock = threading.Lock()
cache_dirty = False


# ==================== فایل‌ها و زمان ====================

def utc_now():
    return datetime.now(timezone.utc)


def parse_date(value):
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if result.tzinfo is None:
            result = result.replace(tzinfo=timezone.utc)
        return result
    except Exception:
        return None


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    temp_path = path + ".tmp"
    with file_lock:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(temp_path, path)


def save_cache(cache):
    # Snapshot زیر قفل ساخته می‌شود؛ فایل بیرون قفل نوشته می‌شود.
    with cache_lock:
        snapshot = dict(cache)

    temp_path = CACHE_FILE + ".tmp"
    with file_lock:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(temp_path, CACHE_FILE)


def load_cache():
    data = load_json(CACHE_FILE, {})
    return data if isinstance(data, dict) else {}


def cache_is_fresh(bars):
    if not isinstance(bars, list) or len(bars) < CANDLES:
        return False
    try:
        age_seconds = time.time() - float(bars[-1]["time"])
        return -3600 <= age_seconds <= MAX_CACHE_AGE_HOURS * 3600
    except (KeyError, TypeError, ValueError, IndexError):
        return False


# ==================== دریافت نمادها ====================

def get_symbols():
    last_error = None
    for attempt in range(1, RETRIES + 1):
        try:
            print(f"دریافت فهرست قراردادها (تلاش {attempt}/{RETRIES})...")
            response = requests.get(
                INSTRUMENT_URL,
                params={"productGroup": "SwapU"},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=25
            )
            response.raise_for_status()
            payload = response.json()

            if payload.get("result") is False:
                raise RuntimeError(str(payload))

            symbols = set()
            for item in payload.get("data", []):
                if isinstance(item, str):
                    raw = item
                elif isinstance(item, dict):
                    raw = (
                        item.get("symbol")
                        or item.get("contractCode")
                        or item.get("instrumentId")
                        or item.get("name")
                        or ""
                    )
                else:
                    continue

                raw = str(raw).upper().strip()
                raw = raw.replace("/", "").replace("-", "").replace("_", "")
                if raw.endswith(".P"):
                    raw = raw[:-2]
                if not raw.endswith("USDT"):
                    continue

                base = raw[:-4]
                if not base or base in EXCLUDED_BASES or base in EXCLUDED_NONCRYPTO:
                    continue
                if not base.isalnum():
                    continue
                symbols.add(raw)

            if not symbols:
                raise RuntimeError("پاسخ دریافت شد، اما نمادی پیدا نشد.")

            result = sorted(symbols)
            print("تعداد نمادهای باقی‌مانده:", len(result))
            return result

        except Exception as exc:
            last_error = exc
            print("خطا:", str(exc)[:250])
            if attempt < RETRIES:
                time.sleep(attempt * 3)

    raise RuntimeError("دریافت فهرست قراردادها ناموفق بود: " + str(last_error))


# ==================== پروتکل TradingView ====================

def tv_message(method, params):
    message = json.dumps({"m": method, "p": params}, separators=(",", ":"))
    return "~m~" + str(len(message)) + "~m~" + message


def unpack_frames(raw):
    frames = []
    pos = 0
    while pos < len(raw):
        if not raw.startswith("~m~", pos):
            pos += 1
            continue
        start = pos + 3
        sep = raw.find("~m~", start)
        if sep == -1:
            break
        try:
            length = int(raw[start:sep])
        except ValueError:
            pos = sep + 3
            continue
        body_start = sep + 3
        body_end = body_start + length
        if body_end > len(raw):
            break
        frames.append(raw[body_start:body_end])
        pos = body_end
    return frames


def collect_bars(raw_messages):
    bars = {}
    for raw in raw_messages:
        for frame in unpack_frames(raw):
            if frame.startswith("~h~"):
                continue
            try:
                msg = json.loads(frame)
            except Exception:
                continue
            if msg.get("m") != "timescale_update":
                continue

            params = msg.get("p", [])
            if len(params) < 2 or not isinstance(params[1], dict):
                continue

            for value in params[1].values():
                if not isinstance(value, dict):
                    continue
                for entry in value.get("s", []):
                    v = entry.get("v", [])
                    if len(v) < 6:
                        continue
                    try:
                        timestamp = int(v[0])
                        bars[timestamp] = {
                            "time": timestamp,
                            "open": float(v[1]),
                            "high": float(v[2]),
                            "low": float(v[3]),
                            "close": float(v[4]),
                            "volume": float(v[5])
                        }
                    except (ValueError, TypeError):
                        continue
    return sorted(bars.values(), key=lambda item: item["time"])


def get_tv_candles(symbol):
    tv_symbol = "LBANK:" + symbol + ".P"
    raw_messages = []
    ws = None
    try:
        ws = websocket.create_connection(
            TV_URL,
            timeout=12,
            origin="https://www.tradingview.com",
            header=["User-Agent: Mozilla/5.0"],
            enable_multithread=True
        )
        ws.settimeout(3)

        chart_session = "cs_" + str(random.randint(100000, 999999))
        quote_session = "qs_" + str(random.randint(100000, 999999))
        symbol_id = "symbol_1"

        ws.send(tv_message("chart_create_session", [chart_session, ""]))
        ws.send(tv_message("quote_create_session", [quote_session]))
        ws.send(tv_message("quote_set_fields", [
            quote_session, "lp", "lp_time", "volume", "bid", "ask"
        ]))
        ws.send(tv_message("resolve_symbol", [
            chart_session,
            symbol_id,
            '={"symbol":"' + tv_symbol +
            '","adjustment":"splits","session":"regular"}'
        ]))
        ws.send(tv_message("create_series", [
            chart_session, "s1", "s1", symbol_id, INTERVAL, CANDLES, ""
        ]))

        deadline = time.time() + DATA_WAIT_SECONDS
        while time.time() < deadline:
            try:
                message = ws.recv()
                if not message:
                    continue
                if isinstance(message, bytes):
                    message = message.decode("utf-8", errors="ignore")
                raw_messages.append(message)
                bars = collect_bars(raw_messages)
                if len(bars) >= CANDLES:
                    return bars[-CANDLES:]
            except websocket.WebSocketTimeoutException:
                continue

        return collect_bars(raw_messages)[-CANDLES:]

    except Exception:
        return []
    finally:
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass


# ==================== تحلیل خط روند ====================

def find_pivots(bars, kind, left=3, right=3):
    result = []
    key = "high" if kind == "high" else "low"
    for i in range(left, len(bars) - right):
        value = bars[i][key]
        before = [bars[j][key] for j in range(i - left, i)]
        after = [bars[j][key] for j in range(i + 1, i + right + 1)]
        if kind == "high":
            if value >= max(before) and value >= max(after):
                result.append((i, value))
        else:
            if value <= min(before) and value <= min(after):
                result.append((i, value))
    return result


def spaced_touches(indices, minimum_gap):
    selected = []
    for index in indices:
        if not selected or index - selected[-1] >= minimum_gap:
            selected.append(index)
    return selected


def analyze(symbol, bars):
    if not isinstance(bars, list) or len(bars) < CANDLES:
        return None

    bars = sorted(bars, key=lambda item: item["time"])[-CANDLES:]
    highs = find_pivots(bars, "high")
    if len(highs) < 2:
        return None

    last_index = len(bars) - 1
    price = bars[-1]["close"]
    if price <= 0:
        return None

    best = None

    # خط از دو سقف چرخشی ساخته می‌شود و در کل پنجره 200 کندلی آزمایش می‌شود.
    for a in range(len(highs) - 1):
        i1, p1 = highs[a]
        for b in range(a + 1, len(highs)):
            i2, p2 = highs[b]
            if i2 - i1 < MIN_SPAN:
                continue

            slope = (p2 - p1) / (i2 - i1)
            if slope >= 0:
                continue

            def line_at(index):
                return p1 + slope * (index - i1)

            touch_indices = []
            for idx, pivot_price in highs:
                if idx < i1:
                    continue
                line_price = line_at(idx)
                if line_price <= 0:
                    continue
                gap = abs(pivot_price - line_price) / line_price * 100
                if gap <= TOUCH_TOLERANCE and pivot_price <= line_price * (1 + MAX_BREAK / 100):
                    touch_indices.append(idx)

            touch_indices = spaced_touches(sorted(set(touch_indices)), MIN_TOUCH_GAP)
            if len(touch_indices) < MIN_TOUCHES:
                continue

            span = touch_indices[-1] - touch_indices[0]
            if span < MIN_SPAN:
                continue

            last_touch_age = last_index - touch_indices[-1]
            if last_touch_age > MAX_LAST_TOUCH_AGE:
                continue

            current_line = line_at(last_index)
            if current_line <= 0:
                continue

            distance = (price - current_line) / current_line * 100
            if abs(distance) > MAX_DISTANCE:
                continue

            broken = False
            for idx in range(i1, len(bars)):
                line_price = line_at(idx)
                if line_price > 0 and bars[idx]["high"] > line_price * (1 + MAX_BREAK / 100):
                    broken = True
                    break
            if broken:
                continue

            score = (
                len(touch_indices) * 100
                + span * 0.5
                - abs(distance) * 10
                - last_touch_age * 0.2
            )
            candidate = {
                "symbol": symbol,
                "price": round(price, 10),
                "trendline": round(current_line, 10),
                "distance_percent": round(distance, 4),
                "touches": len(touch_indices),
                "last_touch_age_candles": last_touch_age,
                "span_candles": span,
                "candles_analyzed": len(bars),
                "score": round(score, 3),
                "last_candle_time": bars[-1]["time"]
            }
            if best is None or candidate["score"] > best["score"]:
                best = candidate

    return best


# ==================== تاریخچه نمایش ====================

def load_seen():
    data = load_json(SEEN_FILE, {})
    if not isinstance(data, dict):
        return {}
    now = utc_now()
    cleaned = {}
    for symbol, value in data.items():
        if not isinstance(value, dict):
            continue
        seen_date = parse_date(value.get("shown_at", ""))
        if seen_date is not None and now - seen_date < timedelta(days=COOLDOWN_DAYS):
            cleaned[symbol] = value
    return cleaned


def is_in_cooldown(symbol, seen):
    value = seen.get(symbol)
    if not isinstance(value, dict):
        return False
    seen_date = parse_date(value.get("shown_at", ""))
    return seen_date is not None and utc_now() - seen_date < timedelta(days=COOLDOWN_DAYS)


def mark_as_shown(results, seen):
    now = utc_now().isoformat()
    for item in results:
        seen[item["symbol"]] = {
            "shown_at": now,
            "distance_percent": item["distance_percent"],
            "touches": item["touches"]
        }
    save_json(SEEN_FILE, seen)


# ==================== اجرای اصلی ====================

def main():
    global cache_dirty
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    print("=" * 55)
    print("LBank Futures - Descending Trendline Scanner")
    print("تایم‌فریم: 4 ساعت | کندل موردنیاز: 120")
    print("فاصله قیمت تا خط: حداکثر 1 درصد")
    print("حداقل برخورد: 3 | عدم تکرار: 10 روز")
    print("=" * 55)

    try:
        symbols = get_symbols()
    except Exception as exc:
        print("دریافت فهرست قراردادها ناموفق بود.")
        print(str(exc))
        return

    cache = load_cache()
    seen = load_seen()
    candidates = []
    total = len(symbols)
    failed = 0
    cache_used = 0
    completed = 0

    print("\nشروع دریافت کندل‌های 4 ساعته TradingView...")
    print("اگر برای نمادی 120 کندل معتبر در دسترس نباشد، آن نماد رد می‌شود.\n")

    def worker(symbol):
        nonlocal cache_used

        bars = get_tv_candles(symbol)
        if bars and len(bars) >= CANDLES:
            bars = sorted(bars, key=lambda item: item["time"])[-CANDLES:]
            with cache_lock:
                cache[symbol] = {
                    "saved_at": utc_now().isoformat(),
                    "bars": bars
                }
        else:
            with cache_lock:
                old = cache.get(symbol, {})
                old_bars = old.get("bars", [])
            if cache_is_fresh(old_bars):
                bars = sorted(old_bars, key=lambda item: item["time"])[-CANDLES:]
                with cache_lock:
                    cache_used += 1
            else:
                bars = []

        if not bars or len(bars) < CANDLES:
            return symbol, None, False
        return symbol, analyze(symbol, bars), True

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(worker, symbol): symbol for symbol in symbols}

        for future in as_completed(futures):
            completed += 1
            try:
                symbol, result, data_ok = future.result()
                if not data_ok:
                    failed += 1
                if result is not None:
                    candidates.append(result)
            except Exception as exc:
                failed += 1
                print(f"خطا در پردازش {futures[future]}: {str(exc)[:120]}")

            if completed % 25 == 0 or completed == total:
                print(
                    f"بررسی {completed}/{total} | "
                    f"کاندیدا: {len(candidates)} | "
                    f"خطا/داده ناکافی: {failed} | "
                    f"استفاده از کش تازه: {cache_used}"
                )

            if completed % 50 == 0:
                try:
                    save_cache(cache)
                except Exception as exc:
                    print("هشدار ذخیره کش:", str(exc)[:150])

    try:
        save_cache(cache)
    except Exception as exc:
        print("هشدار: ذخیره نهایی کش ناموفق بود:", str(exc))

    candidates.sort(
        key=lambda item: (
            item["score"],
            item["touches"],
            item["span_candles"],
            -abs(item["distance_percent"])
        ),
        reverse=True
    )

    fresh_results = []
    for item in candidates:
        if is_in_cooldown(item["symbol"], seen):
            continue
        fresh_results.append(item)
        if len(fresh_results) >= MAX_RESULTS:
            break

    repeated_count = sum(1 for item in candidates if is_in_cooldown(item["symbol"], seen))

    print("\n" + "=" * 65)
    print("نتایج جدید:", len(fresh_results))
    print("کاندیداهای دارای خط روند:", len(candidates))
    print("کنار گذاشته‌شده به‌دلیل تکرار 10 روزه:", repeated_count)
    print("استفاده از کش تازه:", cache_used)
    print("=" * 65)

    if not fresh_results:
        print("نتیجه جدیدی باقی نماند؛ ممکن است کاندیداها تکراری باشند یا داده کافی نباشد.")

    for rank, item in enumerate(fresh_results, 1):
        side = "بالای خط" if item["distance_percent"] >= 0 else "پایین خط"
        print(
            f"\n{rank}. {item['symbol']}"
            f"\n   قیمت: {item['price']}"
            f"\n   مقدار خط روند: {item['trendline']}"
            f"\n   فاصله: {abs(item['distance_percent']):.3f}% {side}"
            f"\n   تعداد برخورد: {item['touches']}"
            f"\n   آخرین برخورد: {item['last_touch_age_candles']} کندل قبل"
            f"\n   گستره برخوردها: {item['span_candles']} کندل"
            f"\n   کندل تحلیل‌شده: {item['candles_analyzed']}"
            f"\n   امتیاز: {item['score']}"
        )

    mark_as_shown(fresh_results, seen)

    output = {
        "scan_time": utc_now().isoformat(),
        "timeframe": "4h",
        "candles_requested": CANDLES,
        "cooldown_days": COOLDOWN_DAYS,
        "symbols_scanned": total,
        "failed_or_insufficient_data": failed,
        "fresh_cache_used": cache_used,
        "candidates_found": len(candidates),
        "results_count": len(fresh_results),
        "results": fresh_results
    }
    save_json(OUTPUT_FILE, output)

    print("\n" + "=" * 55)
    print("اسکن تمام شد.")
    print("فایل نتایج:", OUTPUT_FILE)
    print("تاریخچه 10 روزه:", SEEN_FILE)
    print("کش کندل‌ها:", CACHE_FILE)
    print("=" * 55)


if __name__ == "__main__":
    main()
