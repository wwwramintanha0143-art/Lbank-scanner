package com.example.lbankscanner

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private lateinit var startButton: Button
    private lateinit var statusView: TextView
    private val logFile by lazy { File(filesDir, "scanner.log") }
    @Volatile private var running = false

    private val poller = object : Runnable {
        override fun run() {
            try {
                if (logFile.exists()) {
                    val all = logFile.readText(Charsets.UTF_8)
                    logView.text = if (all.length > 16000) all.takeLast(16000) else all
                    (logView.parent as? ScrollView)?.post { (logView.parent as ScrollView).fullScroll(View.FOCUS_DOWN) }
                }
            } catch (_: Exception) {}
            statusView.text = if (running) "وضعیت: اسکن در حال اجراست" else "وضعیت: آماده"
            startButton.isEnabled = !running
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 16)
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        val title = TextView(this).apply {
            text = "اسکنر روند نزولی LBank"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        val subtitle = TextView(this).apply {
            text = "فیوچرز USDT • کندل ۴ ساعته • ۱۲۰ کندل • حداقل ۳ برخورد • عدم تکرار ۱۰ روزه"
            textSize = 14f
            setTextColor(Color.rgb(190, 200, 220))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        startButton = Button(this).apply {
            text = "شروع اسکن"
            setOnClickListener { startScan() }
        }
        val clearButton = Button(this).apply {
            text = "پاک کردن گزارش صفحه"
            setOnClickListener { logView.text = ""; logFile.writeText("") }
        }
        statusView = TextView(this).apply {
            text = "وضعیت: آماده"
            textSize = 14f
            setTextColor(Color.rgb(120, 220, 170))
            setPadding(0, 8, 0, 8)
        }
        logView = TextView(this).apply {
            text = "برای شروع، دکمه «شروع اسکن» را بزن.\nاسکن ممکن است طولانی شود؛ برنامه را در پس‌زمینه نبند."
            textSize = 13f
            setTextColor(Color.rgb(230, 235, 245))
            setTextIsSelectable(true)
            setPadding(12, 12, 12, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            setBackgroundColor(Color.rgb(24, 31, 47))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(startButton)
        root.addView(clearButton)
        root.addView(statusView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        handler.post(poller)
    }

    private fun startScan() {
        if (running) return
        running = true
        logFile.writeText("شروع برنامه...\n")
        Toast.makeText(this, "اسکن شروع شد", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                val py = Python.getInstance()
                val module = py.getModule("scanner")
                module.callAttr("configure", filesDir.absolutePath)
                module.callAttr("main")
                logFile.appendText("\nاجرای اسکن پایان یافت.\n")
            } catch (e: Exception) {
                try { logFile.appendText("\nخطای برنامه: ${e.message}\n") } catch (_: Exception) {}
            } finally {
                running = false
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        executor.shutdown()
        super.onDestroy()
    }
}
