plugins {
    id("com.android.application") version "8.10.1" apply false
    id("com.chaquo.python") version "16.1.0" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
}
